'use strict';
/* Vercel function: validate an enquiry, save it in Supabase, then notify the saved business email.
   Browser-supplied recipients, subjects, HTML, owner IDs and notification state are ignored. */
const { MAX_BODY_BYTES, EMAIL_RE, validate, buildEmail } = require('../lib/enquiry');

const hits = new Map();
const WINDOW_MS = 10 * 60 * 1000, MAX_HITS = 5;
function rateLimited(ip, now) {
  const arr = (hits.get(ip) || []).filter(t => now - t < WINDOW_MS);
  arr.push(now); hits.set(ip, arr);
  if (hits.size > 5000) for (const [k, v] of hits) if (!v.some(t => now - t < WINDOW_MS)) hits.delete(k);
  return arr.length > MAX_HITS;
}
function serverApiKey(env) { return env.SUPABASE_SECRET_KEY || env.SUPABASE_SERVICE_ROLE_KEY || ''; }
function restUrl(env, path) {
  if (!env.SUPABASE_URL || !serverApiKey(env)) throw new Error('Supabase server configuration missing');
  return env.SUPABASE_URL.replace(/\/+$/, '') + '/rest/v1/' + path;
}
async function supabaseRequest(env, path, options) {
  const o = options || {};
  // Supabase's modern sb_secret_... keys are opaque keys, not JWTs. Send the key
  // in apikey; the gateway handles authentication. Do not put it in Authorization.
  const headers = Object.assign({
    'apikey': serverApiKey(env),
    'Content-Type': 'application/json'
  }, o.headers || {});
  const response = await fetch(restUrl(env, path), { method: o.method || 'GET', headers, body: o.body === undefined ? undefined : JSON.stringify(o.body) });
  const raw = await response.text();
  let data = null;
  try { data = raw ? JSON.parse(raw) : null; } catch (_) { data = null; }
  if (!response.ok) {
    const err = new Error('Supabase request failed (' + response.status + ')');
    err.status = response.status; err.data = data; throw err;
  }
  return data;
}
async function getSiteConfig(env) {
  const rows = await supabaseRequest(env, 'site_settings?select=owner_id,config&id=eq.1&limit=1');
  if (!Array.isArray(rows) || !rows.length) return null;
  return { owner_id: rows[0].owner_id, config: rows[0].config || {} };
}
async function findExistingEnquiry(env, ownerId, clientRequestId) {
  const q = 'enquiries?select=id,email_status&owner_id=eq.' + encodeURIComponent(ownerId) +
    '&client_request_id=eq.' + encodeURIComponent(clientRequestId) + '&limit=1';
  const rows = await supabaseRequest(env, q);
  return Array.isArray(rows) && rows.length ? rows[0] : null;
}
async function saveEnquiry(env, row) {
  const rows = await supabaseRequest(env, 'enquiries', { method: 'POST', headers: { Prefer: 'return=representation' }, body: row });
  return Array.isArray(rows) ? rows[0] : null;
}
async function findPublishedProduct(env, productId) {
  const rows = await supabaseRequest(env, 'products?select=id,name&published=eq.true&id=eq.' + encodeURIComponent(productId) + '&limit=1');
  return Array.isArray(rows) && rows.length ? rows[0] : null;
}
async function updateEmailStatus(env, id, ownerId, status) {
  const filter = 'enquiries?id=eq.' + encodeURIComponent(id) + '&owner_id=eq.' + encodeURIComponent(ownerId);
  await supabaseRequest(env, filter, { method: 'PATCH', headers: { Prefer: 'return=minimal' }, body: { email_status: status } });
}
async function sendWithResend(env, mail, to, idempotencyKey) {
  const payload = { from: env.RESEND_FROM, to: [to], subject: mail.subject, html: mail.html, text: mail.text };
  if (mail.replyTo) payload.reply_to = mail.replyTo;
  const r = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { 'Authorization': 'Bearer ' + env.RESEND_API_KEY, 'Content-Type': 'application/json', 'Idempotency-Key': idempotencyKey },
    body: JSON.stringify(payload)
  });
  let j = {};
  try { j = await r.json(); } catch (_) { /* provider returned no JSON */ }
  return { accepted: r.ok && !!j.id, status: r.status, id: j.id };
}
const SETUP_VARS = ['SUPABASE_URL'];
function createHandler(deps) {
  const d = Object.assign({ getSiteConfig, findExistingEnquiry, saveEnquiry, findPublishedProduct, updateEmailStatus, sendEmail: sendWithResend, now: () => new Date(), env: process.env }, deps || {});
  return async function handler(req, res) {
    const send = (code, obj) => { res.status(code).setHeader('Cache-Control', 'no-store'); res.json(obj); };
    const env = d.env;
    if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return send(405, { ok: false, error: 'method_not_allowed' }); }
    const allowed = (env.ALLOWED_ORIGIN || '').split(',').map(s => s.trim()).filter(Boolean);
    const origin = req.headers && req.headers.origin;
    if (allowed.length && origin && !allowed.includes(origin)) return send(403, { ok: false, error: 'forbidden_origin' });
    const len = parseInt((req.headers && req.headers['content-length']) || '0', 10);
    if (len > MAX_BODY_BYTES) return send(413, { ok: false, error: 'too_large' });
    let body = req.body;
    if (typeof body === 'string') { try { body = JSON.parse(body); } catch (_) { return send(400, { ok: false, error: 'invalid', message: 'Invalid request.' }); } }
    if (body && JSON.stringify(body).length > MAX_BODY_BYTES) return send(413, { ok: false, error: 'too_large' });
    if (body && typeof body === 'object' && typeof body.website === 'string' && body.website.trim() !== '') return send(200, { ok: true, saved: false });
    const v = validate(body);
    if (!v.ok) return send(400, { ok: false, error: 'invalid', message: v.message });
    const missing = SETUP_VARS.filter(k => !env[k]);
    if (!serverApiKey(env)) missing.push('SUPABASE_SECRET_KEY');
    if (missing.length) return send(503, { ok: false, error: 'setup_required', message: 'The online enquiry database is not configured yet.' });
    const ip = ((req.headers && req.headers['x-forwarded-for']) || (req.socket && req.socket.remoteAddress) || 'unknown').split(',')[0].trim();
    if (rateLimited(ip, d.now().getTime())) return send(429, { ok: false, error: 'rate_limited' });

    try {
      const site = await d.getSiteConfig(env);
      if (!site || !site.owner_id) return send(503, { ok: false, error: 'setup_required', message: 'The owner website settings have not been initialized.' });
      const cfg = site.config || {};
      const savedEmail = cfg.business && typeof cfg.business.email === 'string' ? cfg.business.email.trim() : '';
      const recipient = EMAIL_RE.test(savedEmail) ? savedEmail : String(env.DEFAULT_RECIPIENT_EMAIL || '').trim();
      const existing = await d.findExistingEnquiry(env, site.owner_id, v.data.clientRequestId);
      if (existing) return send(200, { ok: true, saved: true, duplicate: true, notificationSent: existing.email_status === 'sent', notificationStatus: existing.email_status });

      const item = v.data;
      if (item.enquiryType === 'product') {
        const product = item.productId ? await d.findPublishedProduct(env, item.productId) : null;
        if (!product) return send(400, { ok: false, error: 'invalid_product', message: 'That product is no longer available. Refresh the page and try again.' });
        item.productName = product.name;
      }
      const row = {
        owner_id: site.owner_id,
        client_request_id: item.clientRequestId,
        enquiry_type: item.enquiryType,
        customer_name: item.name,
        phone: item.phone,
        email: item.email,
        contact_method: item.contactMethod,
        appliance: item.appliance,
        brand: item.brand,
        symptom: item.symptom,
        notes: item.notes,
        area: item.area,
        product_id: item.productId || null,
        product_name: item.productName,
        status: 'new',
        email_status: 'pending'
      };
      const saved = await d.saveEnquiry(env, row);
      if (!saved || !saved.id) throw new Error('Supabase did not confirm the enquiry was saved');

      let notificationSent = false, emailStatus = 'not_configured';
      if (recipient && EMAIL_RE.test(recipient) && env.RESEND_API_KEY && env.RESEND_FROM) {
        try {
          const bizName = (cfg.business && cfg.business.name) || 'D.S. Electrical';
          const mail = buildEmail(item, bizName, d.now(), env.TIMEZONE);
          const result = await d.sendEmail(env, mail, recipient, (env.SITE_ID || 'ds-electrical') + '-' + item.clientRequestId);
          notificationSent = !!result.accepted;
          emailStatus = notificationSent ? 'sent' : 'failed';
          if (!notificationSent) console.error('Email provider did not accept enquiry notification, status', result.status);
        } catch (err) {
          emailStatus = 'failed';
          console.error('Enquiry saved; email notification failed:', err && err.message);
        }
      }
      try { await d.updateEmailStatus(env, saved.id, site.owner_id, emailStatus); }
      catch (err) { console.error('Could not update enquiry email status:', err && err.message); }
      return send(200, { ok: true, saved: true, notificationSent, notificationStatus: emailStatus });
    } catch (err) {
      if (err && err.status === 409) return send(409, { ok: false, error: 'duplicate_conflict', message: 'This enquiry may already have been received. Please refresh before retrying.' });
      console.error('save-enquiry failed:', err && err.message);
      return send(502, { ok: false, error: 'save_failed', message: 'We could not save your enquiry. Please try again.' });
    }
  };
}
module.exports = createHandler();
module.exports.createHandler = createHandler;
module.exports._hits = hits;
module.exports._internals = { supabaseRequest, getSiteConfig, findExistingEnquiry, saveEnquiry, findPublishedProduct, updateEmailStatus };
