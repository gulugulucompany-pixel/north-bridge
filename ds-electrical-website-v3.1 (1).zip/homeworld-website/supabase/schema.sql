-- D.S. Electrical website schema for Supabase (Postgres + Auth + Storage).
-- Run this in Supabase SQL Editor before configuring the site.
-- Then create an owner account in Authentication and follow README.md to insert site_settings.

create extension if not exists pgcrypto;

create table if not exists public.site_settings (
  id smallint primary key default 1 check (id = 1),
  owner_id uuid not null references auth.users(id) on delete cascade,
  config jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name varchar(120) not null check (char_length(trim(name)) between 1 and 120),
  description varchar(2000) not null default '',
  category varchar(80) not null default '',
  price numeric(12,2) null check (price is null or price >= 0),
  availability text not null default 'ask' check (availability in ('available', 'out_of_stock', 'preorder', 'ask')),
  image_url text not null default '',
  published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.enquiries (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  client_request_id varchar(64) not null,
  enquiry_type text not null default 'repair' check (enquiry_type in ('repair', 'product')),
  customer_name varchar(100) not null,
  phone varchar(30) not null,
  email varchar(254) not null default '',
  contact_method varchar(20) not null default 'Phone call',
  appliance varchar(60) not null default '',
  brand varchar(60) not null default '',
  symptom varchar(120) not null default '',
  notes varchar(2000) not null default '',
  area varchar(120) not null default '',
  product_id uuid null references public.products(id) on delete set null,
  product_name varchar(120) not null default '',
  status text not null default 'new' check (status in ('new', 'contacted', 'resolved', 'archived')),
  email_status text not null default 'pending' check (email_status in ('pending', 'sent', 'failed', 'not_configured')),
  created_at timestamptz not null default now(),
  unique (owner_id, client_request_id)
);

create index if not exists products_published_created_idx on public.products (published, created_at desc);
create index if not exists enquiries_owner_created_idx on public.enquiries (owner_id, created_at desc);

create or replace function public.touch_updated_at()
returns trigger language plpgsql set search_path = public as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists site_settings_touch_updated_at on public.site_settings;
create trigger site_settings_touch_updated_at before update on public.site_settings
for each row execute function public.touch_updated_at();

drop trigger if exists products_touch_updated_at on public.products;
create trigger products_touch_updated_at before update on public.products
for each row execute function public.touch_updated_at();

alter table public.site_settings enable row level security;
alter table public.products enable row level security;
alter table public.enquiries enable row level security;

drop policy if exists "Public can read published site settings" on public.site_settings;
create policy "Public can read published site settings" on public.site_settings
for select to anon, authenticated using (true);
drop policy if exists "Owner can update site settings" on public.site_settings;
create policy "Owner can update site settings" on public.site_settings
for update to authenticated using (auth.uid() = owner_id) with check (auth.uid() = owner_id);

-- Public visitors can read published products only. Mutations are limited to the one
-- owner registered in site_settings, not just any authenticated account.
drop policy if exists "Public can read published products" on public.products;
create policy "Public can read published products" on public.products
for select to anon, authenticated using (published = true);
drop policy if exists "Owner can read all own products" on public.products;
create policy "Owner can read all own products" on public.products
for select to authenticated using (
  auth.uid() = owner_id and auth.uid() = (select owner_id from public.site_settings where id = 1)
);
drop policy if exists "Owner can insert own products" on public.products;
create policy "Owner can insert own products" on public.products
for insert to authenticated with check (
  auth.uid() = owner_id and auth.uid() = (select owner_id from public.site_settings where id = 1)
);
drop policy if exists "Owner can update own products" on public.products;
create policy "Owner can update own products" on public.products
for update to authenticated using (
  auth.uid() = owner_id and auth.uid() = (select owner_id from public.site_settings where id = 1)
) with check (
  auth.uid() = owner_id and auth.uid() = (select owner_id from public.site_settings where id = 1)
);
drop policy if exists "Owner can delete own products" on public.products;
create policy "Owner can delete own products" on public.products
for delete to authenticated using (
  auth.uid() = owner_id and auth.uid() = (select owner_id from public.site_settings where id = 1)
);

-- Enquiries can only be read/updated by the site's designated authenticated owner.
-- No anon INSERT policy is granted: the validated Vercel function uses the server-only secret key.
drop policy if exists "Owner can read own enquiries" on public.enquiries;
create policy "Owner can read own enquiries" on public.enquiries
for select to authenticated using (
  auth.uid() = owner_id and auth.uid() = (select owner_id from public.site_settings where id = 1)
);
drop policy if exists "Owner can update own enquiries" on public.enquiries;
create policy "Owner can update own enquiries" on public.enquiries
for update to authenticated using (
  auth.uid() = owner_id and auth.uid() = (select owner_id from public.site_settings where id = 1)
) with check (
  auth.uid() = owner_id and auth.uid() = (select owner_id from public.site_settings where id = 1)
);

grant select on public.site_settings to anon, authenticated;
grant update (config, updated_at) on public.site_settings to authenticated;
grant select on public.products to anon, authenticated;
grant insert, update, delete on public.products to authenticated;
grant select, update (status) on public.enquiries to authenticated;

-- Persistent product images. Images are publicly readable; only the registered owner may upload/change/delete them.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('product-images', 'product-images', true, 5242880, array['image/jpeg','image/png','image/webp','image/avif'])
on conflict (id) do update set public = true, file_size_limit = 5242880,
  allowed_mime_types = array['image/jpeg','image/png','image/webp','image/avif'];

drop policy if exists "Public can view product images" on storage.objects;
create policy "Public can view product images" on storage.objects
for select to anon, authenticated using (bucket_id = 'product-images');
drop policy if exists "Owner can upload product images" on storage.objects;
create policy "Owner can upload product images" on storage.objects
for insert to authenticated with check (
  bucket_id = 'product-images' and auth.uid() = (select owner_id from public.site_settings where id = 1)
);
drop policy if exists "Owner can update product images" on storage.objects;
create policy "Owner can update product images" on storage.objects
for update to authenticated using (
  bucket_id = 'product-images' and auth.uid() = (select owner_id from public.site_settings where id = 1)
) with check (
  bucket_id = 'product-images' and auth.uid() = (select owner_id from public.site_settings where id = 1)
);
drop policy if exists "Owner can delete product images" on storage.objects;
create policy "Owner can delete product images" on storage.objects
for delete to authenticated using (
  bucket_id = 'product-images' and auth.uid() = (select owner_id from public.site_settings where id = 1)
);
