'use strict';
/* Run with: node test/test.js. Network calls are replaced with injected test doubles. */
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const { validate, buildEmail, escapeHtml } = require('../lib/enquiry');
const { createHandler, _hits } = require('../api/send-repair-request');

let pass = 0;
async function t(name, fn) { try { await fn(); pass++; console.log('  ok  ' + name); } catch (e) { console.error('FAIL ' + name + '\n     ' + e.message); process.exitCode = 1; } }
const good = () => ({
  clientRequestId: 'abcd1234-efgh', enquiryType: 'repair', appliance: 'Washing Machine', brand: 'Bosch', symptom: 'Will not drain or spin out', notes: 'Code F21',
  area: 'Marina & Presidio (94123)', name: 'Jo Smith', phone: '(555) 123-4567', email: 'jo@example.com', contactMethod: 'Email', website: ''
});
const site = () => ({ owner_id: '11111111-1111-4111-8111-111111111111', config: { business: { email: 'owner@example.com', name: 'Test <Biz>' } } });
const env = () => ({ SUPABASE_URL: 'https://example.supabase.co', SUPABASE_SECRET_KEY: 'sb_secret_testkey', RESEND_API_KEY: 'k', RESEND_FROM: 'Site <onboarding@resend.dev>', SITE_ID: 'homeworld', TIMEZONE: 'Asia/Kathmandu' });
function run(handler, body, headers) {
  return new Promise(resolve => {
    const res = { code: 200, headers: {}, status(c) { this.code = c; return this; }, setHeader(k, v) { this.headers[k] = v; return this; }, json(o) { resolve({ code: this.code, body: o, headers: this.headers }); } };
    handler({ method: 'POST', body, headers: Object.assign({ 'x-forwarded-for': '1.1.1.' + Math.floor(Math.random() * 250) }, headers || {}) }, res);
  });
}
function mk(over) {
  const calls = [], saved = [], updated = [];
  const base = {
    env: env(),
    getSiteConfig: async () => site(),
    findExistingEnquiry: async () => null,
    findPublishedProduct: async (_env, id) => ({ id, name: 'Verified product' }),
    saveEnquiry: async (_env, row) => { saved.push(row); return Object.assign({ id: '22222222-2222-4222-8222-222222222222' }, row); },
    updateEmailStatus: async (_env, id, ownerId, status) => { updated.push({ id, ownerId, status }); },
    sendEmail: async (e, mail, to, key) => { calls.push({ mail, to, key }); return { accepted: true, id: 'resend-id' }; }
  };
  const h = createHandler(Object.assign(base, over || {}));
  return { h, calls, saved, updated };
}

(async () => {
  console.log('Site defaults');
  await t('Opening Times default to blank (unverified) and a saved value is kept', () => {
    const context = { window: {} };
    vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../site-defaults.js'), 'utf8'), context);
    const cfg = context.window.SiteCfg;
    const blank = JSON.parse(JSON.stringify(cfg.normalize(null).business.openingHours));
    assert.deepStrictEqual(blank, [
      { day: 'Monday–Friday', hours: '' },
      { day: 'Saturday', hours: '' },
      { day: 'Sunday', hours: '' }
    ]);
    const saved = cfg.normalize({ business: { openingHours: [{ hours: '8 am – 6 pm' }, { hours: 'By appointment' }, { hours: 'Closed' }] } });
    assert.deepStrictEqual(JSON.parse(JSON.stringify(saved.business.openingHours.map(r => r.hours))), ['8 am – 6 pm', 'By appointment', 'Closed']);
  });
  await t('D.S. Electrical defaults: name, phone and the nine listed services', () => {
    const context = { window: {} };
    vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../site-defaults.js'), 'utf8'), context);
    const d = context.window.SiteCfg.normalize(null);
    assert.strictEqual(d.business.name, 'D.S. Electrical');
    assert.strictEqual(d.business.phone, '+44 7517 269949');
    const labels = d.appliances.map(a => a.label);
    for (const l of ['EV Charger Installation', 'Fuse Box Upgrades', 'Inspection & Testing', 'PAT Testing', 'Rewires', 'Fault Finding', 'Electrical Equipment Repairs', 'New Lights and Sockets', 'Smoke and Heat Alarm Work']) assert.ok(labels.includes(l), l);
    assert.deepStrictEqual(JSON.parse(JSON.stringify(d.areas)), []);
  });

  console.log('Schema policies');
  await t('owner policies are tied to the registered site owner', () => {
    const sql = fs.readFileSync(path.join(__dirname, '../supabase/schema.sql'), 'utf8');
    for (const table of ['public.products', 'public.enquiries']) assert.ok(sql.includes('auth.uid() = (select owner_id from public.site_settings where id = 1)'), table);
    assert.ok(!/create policy[^;]*?on public\.enquiries[\s\S]*?for insert to anon/i.test(sql));
  });

  await t('modern Supabase secret keys are sent as apikey, not JWT bearer tokens', async () => {
    const originalFetch = global.fetch; let seen;
    global.fetch = async (url, options) => { seen = { url, options }; return { ok: true, status: 200, text: async () => '[]' }; };
    try {
      await require('../api/send-repair-request')._internals.supabaseRequest(env(), 'products?select=id');
      assert.strictEqual(seen.options.headers.apikey, 'sb_secret_testkey');
      assert.ok(!Object.prototype.hasOwnProperty.call(seen.options.headers, 'Authorization'));
    } finally { global.fetch = originalFetch; }
  });

  console.log('Validation');
  await t('accepts a valid repair enquiry', () => assert.ok(validate(good()).ok));
  await t('rejects missing name', () => { const b = good(); b.name = ' '; assert.ok(!validate(b).ok); });
  await t('rejects bad phone', () => { const b = good(); b.phone = 'abc'; assert.ok(!validate(b).ok); });
  await t('rejects bad email', () => { const b = good(); b.email = 'not-an-email'; assert.ok(!validate(b).ok); });
  await t('email contact method requires an email', () => { const b = good(); b.email = ''; assert.ok(!validate(b).ok); });
  await t('rejects unknown contact method', () => { const b = good(); b.contactMethod = 'Carrier pigeon'; assert.ok(!validate(b).ok); });
  await t('rejects over-long repair notes', () => { const b = good(); b.notes = 'x'.repeat(1001); assert.ok(!validate(b).ok); });
  await t('rejects non-string fields', () => { const b = good(); b.name = { $ne: 1 }; assert.ok(!validate(b).ok); });
  await t('needs symptom or notes', () => { const b = good(); b.symptom = ''; b.notes = ''; assert.ok(!validate(b).ok); });
  await t('rejects bad request id', () => { const b = good(); b.clientRequestId = '../x'; assert.ok(!validate(b).ok); });
  await t('accepts a product enquiry without appliance/location fields', () => {
    const b = { enquiryType: 'product', clientRequestId: 'product-req-0001', productName: 'Product title', productId: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa', name: 'Jo Smith', phone: '123-456-7890', email: '', contactMethod: 'Phone call', notes: 'Please tell me whether this is available.' };
    assert.ok(validate(b).ok);
  });
  await t('rejects a product ID longer than UUID length', () => { const b = { enquiryType: 'product', clientRequestId: 'product-req-0001', productName: 'Thing', productId: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa-extra', name: 'Jo Smith', phone: '1234567890', contactMethod: 'Phone call', notes: 'Please contact me.' }; assert.ok(!validate(b).ok); });
  await t('requires a product name and message for product enquiries', () => {
    const b = { enquiryType: 'product', clientRequestId: 'product-req-0001', productName: 'Product title', productId: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa', name: 'Jo', phone: '1234567890', contactMethod: 'Phone call', notes: '' };
    assert.ok(!validate(b).ok);
  });

  console.log('Email construction');
  await t('escapes HTML in every value', () => {
    const b = good(); b.name = '<script>alert(1)</script>'; b.notes = '<img src=x onerror=1>"\'&';
    const m = buildEmail(validate(b).data, 'Biz <b>', new Date('2026-01-02T03:04:05Z'), 'UTC');
    assert.ok(!m.html.includes('<script>')); assert.ok(!m.html.includes('<img'));
    assert.ok(m.html.includes('&lt;script&gt;')); assert.ok(m.html.includes('Biz &lt;b&gt;'));
  });
  await t('subject has no newlines (header injection)', () => {
    const b = good(); b.name = 'Bob\r\nBcc: evil@example.com'; b.brand = 'A\nB';
    const m = buildEmail(validate(b).data, 'x', new Date(), 'UTC'); assert.ok(!/[\r\n]/.test(m.subject));
  });
  await t('contains required details and timestamp', () => {
    const m = buildEmail(validate(good()).data, 'Biz', new Date('2026-01-02T03:04:05Z'), 'UTC');
    for (const s of ['Jo Smith', '(555) 123-4567', 'jo@example.com', 'Email', 'Washing Machine', 'Bosch', 'Will not drain', 'Code F21', 'Marina', '2026-01-02T03:04:05.000Z']) assert.ok(m.text.includes(s), s);
  });
  await t('builds a product enquiry email', () => {
    const b = { enquiryType: 'product', clientRequestId: 'product-req-0001', productId: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa', productName: 'Test product', name: 'Jane', phone: '1234567890', email: 'jane@example.com', contactMethod: 'Email', notes: 'Can you confirm stock?' };
    const mail = buildEmail(validate(b).data, 'Homeworld', new Date('2026-01-01T00:00:00Z'), 'UTC');
    assert.ok(mail.subject.includes('Test product')); assert.ok(mail.text.includes('Can you confirm stock?'));
  });
  await t('escapeHtml', () => assert.strictEqual(escapeHtml('<&"\'>'), '&lt;&amp;&quot;&#39;&gt;'));

  console.log('Vercel handler');
  await t('rejects GET', async () => {
    const { h } = mk(); const out = await new Promise(resolve => { const res = { status() { return this; }, setHeader() { return this; }, json: resolve }; h({ method: 'GET', headers: {} }, res); });
    assert.strictEqual(out.error, 'method_not_allowed');
  });
  await t('saves enquiry and emails only the saved business recipient', async () => {
    const { h, calls, saved, updated } = mk();
    const b = Object.assign(good(), { recipientEmail: 'attacker@evil.com', to: 'attacker@evil.com', recipient: 'attacker@evil.com', subject: 'HACKED', html: '<b>x</b>', bcc: 'attacker@evil.com', owner_id: 'wrong-owner' });
    const r = await run(h, b);
    assert.strictEqual(r.code, 200); assert.strictEqual(r.body.saved, true); assert.strictEqual(r.body.notificationSent, true);
    assert.strictEqual(calls.length, 1); assert.strictEqual(calls[0].to, 'owner@example.com');
    assert.ok(!calls[0].mail.subject.includes('HACKED')); assert.ok(!calls[0].mail.html.includes('attacker'));
    assert.strictEqual(calls[0].key, 'homeworld-abcd1234-efgh');
    assert.strictEqual(saved[0].owner_id, site().owner_id); assert.strictEqual(saved[0].customer_name, 'Jo Smith');
    assert.deepStrictEqual(updated[0].status, 'sent');
  });
  await t('honeypot traps bots without saving or emailing', async () => {
    const { h, calls, saved } = mk(); const r = await run(h, Object.assign(good(), { website: 'http://spam' }));
    assert.strictEqual(r.code, 200); assert.strictEqual(calls.length, 0); assert.strictEqual(saved.length, 0);
  });
  await t('missing Supabase server config returns 503 without success', async () => {
    const { h, calls, saved } = mk({ env: {} }); const r = await run(h, good());
    assert.strictEqual(r.code, 503); assert.strictEqual(r.body.error, 'setup_required'); assert.strictEqual(calls.length, 0); assert.strictEqual(saved.length, 0);
  });
  await t('database save failure does not show success or send email', async () => {
    const { h, calls } = mk({ saveEnquiry: async () => { throw new Error('database unavailable'); } }); const r = await run(h, good());
    assert.strictEqual(r.code, 502); assert.strictEqual(r.body.error, 'save_failed'); assert.strictEqual(calls.length, 0);
  });
  await t('provider rejection still reports saved enquiry but failed notification', async () => {
    const { h, saved, updated } = mk({ sendEmail: async () => ({ accepted: false, status: 422 }) }); const r = await run(h, good());
    assert.strictEqual(r.code, 200); assert.strictEqual(r.body.saved, true); assert.strictEqual(r.body.notificationSent, false);
    assert.strictEqual(saved.length, 1); assert.strictEqual(updated[0].status, 'failed');
  });
  await t('provider exception still keeps the saved enquiry', async () => {
    const { h, saved } = mk({ sendEmail: async () => { throw new Error('network'); } }); const r = await run(h, good());
    assert.strictEqual(r.code, 200); assert.strictEqual(r.body.saved, true); assert.strictEqual(r.body.notificationStatus, 'failed'); assert.strictEqual(saved.length, 1);
  });
  await t('settings database failure gives no false success', async () => {
    const { h, calls } = mk({ getSiteConfig: async () => { throw new Error('db'); } }); const r = await run(h, good());
    assert.strictEqual(r.code, 502); assert.strictEqual(calls.length, 0);
  });
  await t('uninitialized site settings blocks saving', async () => {
    const { h, calls, saved } = mk({ getSiteConfig: async () => null }); const r = await run(h, good());
    assert.strictEqual(r.code, 503); assert.strictEqual(calls.length, 0); assert.strictEqual(saved.length, 0);
  });
  await t('trusted env recipient used if saved email is not set', async () => {
    const e = env(); e.DEFAULT_RECIPIENT_EMAIL = 'fallback@example.com';
    const { h, calls } = mk({ env: e, getSiteConfig: async () => ({ owner_id: site().owner_id, config: { business: { name: 'Homeworld', email: '' } } }) });
    await run(h, good()); assert.strictEqual(calls[0].to, 'fallback@example.com');
  });
  await t('current saved business email controls each notification recipient', async () => {
    let savedEmail = 'one@example.com';
    const { h, calls } = mk({ getSiteConfig: async () => ({ owner_id: site().owner_id, config: { business: { email: savedEmail, name: 'Homeworld' } } }) });
    await run(h, good()); savedEmail = 'two@example.com'; await run(h, Object.assign(good(), { clientRequestId: 'ijkl1234-efgh' }));
    assert.deepStrictEqual(calls.map(c => c.to), ['one@example.com', 'two@example.com']);
  });
  await t('rejects enquiries for unpublished or unknown products', async () => {
    const { h, saved, calls } = mk({ findPublishedProduct: async () => null });
    const body = { enquiryType: 'product', clientRequestId: 'product-check-0001', productId: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa', productName: 'Fake product', name: 'Jane', phone: '1234567890', contactMethod: 'Phone call', notes: 'Is this in stock?' };
    const r = await run(h, body); assert.strictEqual(r.code, 400); assert.strictEqual(saved.length, 0); assert.strictEqual(calls.length, 0);
  });
  await t('server uses the product name from the published database row', async () => {
    const { h, saved, calls } = mk({ findPublishedProduct: async (_env, id) => ({ id, name: 'Verified database name' }) });
    const body = { enquiryType: 'product', clientRequestId: 'product-check-0002', productId: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa', productName: 'Spoofed name', name: 'Jane', phone: '1234567890', email: 'jane@example.com', contactMethod: 'Email', notes: 'Is this in stock?' };
    const r = await run(h, body); assert.strictEqual(r.code, 200); assert.strictEqual(saved[0].product_name, 'Verified database name'); assert.ok(calls[0].mail.subject.includes('Verified database name'));
  });
  await t('oversized body rejected', async () => {
    const { h } = mk(); const r = await run(h, Object.assign(good(), { junk: 'x'.repeat(20000) })); assert.strictEqual(r.code, 413);
  });
  await t('invalid input returns 400 before saving', async () => {
    const { h, calls, saved } = mk(); const b = good(); b.phone = 'x'; const r = await run(h, b);
    assert.strictEqual(r.code, 400); assert.strictEqual(calls.length, 0); assert.strictEqual(saved.length, 0);
  });
  await t('origin allow-list blocks other origins', async () => {
    const e = env(); e.ALLOWED_ORIGIN = 'https://good.example'; const { h } = mk({ env: e });
    const r = await run(h, good(), { origin: 'https://bad.example' }); assert.strictEqual(r.code, 403);
  });
  await t('best-effort rate limit trips after 5 from one IP', async () => {
    _hits.clear(); const { h } = mk(); let last;
    for (let i = 0; i < 7; i++) last = await run(h, Object.assign(good(), { clientRequestId: 'request-' + String(i).padStart(4, '0') }), { 'x-forwarded-for': '9.9.9.9' });
    assert.strictEqual(last.code, 429);
  });
  console.log('\n' + pass + ' passed' + (process.exitCode ? ', SOME FAILED' : ''));
})();
